/**
 * 
 */
/**
 * 
 */
module ProyectoCocinaJava {
	requires java.desktop;
}