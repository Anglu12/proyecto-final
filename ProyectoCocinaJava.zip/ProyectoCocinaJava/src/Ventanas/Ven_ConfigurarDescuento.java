package Ventanas;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

/*
 * VENTANA CONFIGURAR DESCUENTOS
 * Esta ventana permite modificar los porcentajes de descuento
 * segun la cantidad de unidades compradas
 * Tiene 4 rangos:
 *   - 1  a  5 unidades
 *   - 6  a 10 unidades
 *   - 11 a 15 unidades
 *   - Mas de 15 unidades
 */
public class Ven_ConfigurarDescuento extends JFrame implements ActionListener {

    private static final long serialVersionUID = 1L;

    // ---- COMPONENTES DE LA VENTANA ----
    private JPanel contentPane;
    private JTextField TxtDescuento1; // campo para 1 a 5 unidades
    private JTextField TxtDescuento2; // campo para 6 a 10 unidades
    private JTextField TxtDescuento3; // campo para 11 a 15 unidades
    private JTextField TxtDescuento4; // campo para mas de 15 unidades
    private JButton btnAceptar;       // boton para guardar los descuentos
    private JButton btnCancelar;      // boton para cerrar sin guardar

    // ---- VARIABLES GLOBALES DE DESCUENTO ----
    // estas variables guardan los porcentajes actuales
    // son publicas y estaticas para que otras ventanas puedan usarlas
    public static double porcentaje1 = 7.5;  // descuento para 1 a 5 unidades
    public static double porcentaje2 = 10.0; // descuento para 6 a 10 unidades
    public static double porcentaje3 = 12.5; // descuento para 11 a 15 unidades
    public static double porcentaje4 = 15.0; // descuento para mas de 15 unidades

    /*
     * METODO MAIN
     * Solo se usa para probar esta ventana directamente
     * sin pasar por el menu principal
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Ven_ConfigurarDescuento frame = new Ven_ConfigurarDescuento();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /*
     * CONSTRUCTOR - Ven_ConfigurarDescuentos()
     * Se ejecuta cuando hacemos:
     *    Ven_ConfigurarDescuentos vd = new Ven_ConfigurarDescuentos();
     * Crea todos los componentes de la ventana
     * Al final llama a mostrarDescuentos() para mostrar los valores actuales
     */
    public Ven_ConfigurarDescuento() {
        setTitle("Configurar porcentajes de descuento");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 480, 230);
        setLocationRelativeTo(null); // centra la ventana
        setResizable(false);

        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setLayout(null);
        setContentPane(contentPane);

        // -- fila 1: 1 a 5 unidades --
        JLabel lbl1 = new JLabel("1 a 5 unidades:");
        lbl1.setBounds(20, 30, 130, 20);
        contentPane.add(lbl1);

        TxtDescuento1 = new JTextField();
        TxtDescuento1.setBounds(160, 28, 100, 22);
        contentPane.add(TxtDescuento1);

        JLabel lblPorcentaje1 = new JLabel("%");
        lblPorcentaje1.setBounds(268, 30, 20, 20);
        contentPane.add(lblPorcentaje1);

        // -- fila 2: 6 a 10 unidades --
        JLabel lbl2 = new JLabel("6 a 10 unidades:");
        lbl2.setBounds(20, 65, 130, 20);
        contentPane.add(lbl2);

        TxtDescuento2 = new JTextField();
        TxtDescuento2.setBounds(160, 63, 100, 22);
        contentPane.add(TxtDescuento2);

        JLabel lblPorcentaje2 = new JLabel("%");
        lblPorcentaje2.setBounds(268, 65, 20, 20);
        contentPane.add(lblPorcentaje2);

        // -- fila 3: 11 a 15 unidades --
        JLabel lbl3 = new JLabel("11 a 15 unidades:");
        lbl3.setBounds(20, 100, 130, 20);
        contentPane.add(lbl3);

        TxtDescuento3 = new JTextField();
        TxtDescuento3.setBounds(160, 98, 100, 22);
        contentPane.add(TxtDescuento3);

        JLabel lblPorcentaje3 = new JLabel("%");
        lblPorcentaje3.setBounds(268, 100, 20, 20);
        contentPane.add(lblPorcentaje3);

        // -- fila 4: mas de 15 unidades --
        JLabel lbl4 = new JLabel("Más de 15 unidades:");
        lbl4.setBounds(20, 135, 140, 20);
        contentPane.add(lbl4);

        TxtDescuento4 = new JTextField();
        TxtDescuento4.setBounds(160, 133, 100, 22);
        contentPane.add(TxtDescuento4);

        JLabel lblPorcentaje4 = new JLabel("%");
        lblPorcentaje4.setBounds(268, 135, 20, 20);
        contentPane.add(lblPorcentaje4);

        // -- boton Aceptar --
        btnAceptar = new JButton("Aceptar");
        btnAceptar.setBounds(360, 28, 90, 25);
        btnAceptar.addActionListener(this); // llama a actionPerformed
        contentPane.add(btnAceptar);

        // -- boton Cancelar --
        btnCancelar = new JButton("Cancelar");
        btnCancelar.setBounds(360, 63, 90, 25);
        btnCancelar.addActionListener(this); // llama a actionPerformed
        contentPane.add(btnCancelar);

        // al abrir muestra los porcentajes actuales
        mostrarDescuentos();
    }

    /*
     * METODO actionPerformed (VOID)
     * Se ejecuta cuando el usuario presiona un boton
     * Detecta cual boton fue presionado y llama al metodo correcto
     *
     * ES LLAMADO POR: btnAceptar y btnCancelar
     */
    public void actionPerformed(ActionEvent e) {

        // si presiono Aceptar
        if (e.getSource() == btnAceptar) {
            accionAceptar(); // llama al metodo accionAceptar
        }

        // si presiono Cancelar
        if (e.getSource() == btnCancelar) {
            accionCancelar(); // llama al metodo accionCancelar
        }
    }

    /*
     * METODO mostrarDescuentos (VOID)
     * Muestra los porcentajes actuales en los campos de texto
     * Los valores vienen de las variables globales porcentaje1..4
     *
     * ES LLAMADO POR: constructor (al abrir la ventana)
     */
    public void mostrarDescuentos() {
        TxtDescuento1.setText(String.valueOf(porcentaje1));
        TxtDescuento2.setText(String.valueOf(porcentaje2));
        TxtDescuento3.setText(String.valueOf(porcentaje3));
        TxtDescuento4.setText(String.valueOf(porcentaje4));
    }

    /*
     * METODO obtenerDescuento1 (RETORNA double)
     * Lee el texto del campo TxtDescuento1
     * y lo convierte a numero decimal
     *
     * ES LLAMADO POR: accionAceptar
     * RETORNA: el porcentaje escrito como numero double
     */
    public double obtenerDescuento1() {
        double valor = Double.parseDouble(TxtDescuento1.getText());
        return valor;
    }

    /*
     * METODO obtenerDescuento2 (RETORNA double)
     * ES LLAMADO POR: accionAceptar
     * RETORNA: el porcentaje escrito como numero double
     */
    public double obtenerDescuento2() {
        double valor = Double.parseDouble(TxtDescuento2.getText());
        return valor;
    }

    /*
     * METODO obtenerDescuento3 (RETORNA double)
     * ES LLAMADO POR: accionAceptar
     * RETORNA: el porcentaje escrito como numero double
     */
    public double obtenerDescuento3() {
        double valor = Double.parseDouble(TxtDescuento3.getText());
        return valor;
    }

    /*
     * METODO obtenerDescuento4 (RETORNA double)
     * ES LLAMADO POR: accionAceptar
     * RETORNA: el porcentaje escrito como numero double
     */
    public double obtenerDescuento4() {
        double valor = Double.parseDouble(TxtDescuento4.getText());
        return valor;
    }

    /*
     * METODO accionAceptar (VOID)
     * Lee los valores escritos usando los metodos obtener
     * Guarda los nuevos porcentajes en las variables globales
     * Muestra mensaje de confirmacion y cierra la ventana
     *
     * ES LLAMADO POR: actionPerformed cuando detecta btnAceptar
     */
    public void accionAceptar() {
        try {
            // llama a los metodos de retorno para leer cada campo
            porcentaje1 = obtenerDescuento1();
            porcentaje2 = obtenerDescuento2();
            porcentaje3 = obtenerDescuento3();
            porcentaje4 = obtenerDescuento4();

            // muestra mensaje de exito
            JOptionPane.showMessageDialog(null,
                "Descuentos guardados correctamente",
                "Aceptar",
                JOptionPane.INFORMATION_MESSAGE);

            dispose(); // cierra la ventana

        } catch (NumberFormatException ex) {
            // si el usuario escribio letras muestra error
            JOptionPane.showMessageDialog(null,
                "Por favor ingrese solo numeros en los campos",
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    /*
     * METODO accionCancelar (VOID)
     * Cierra la ventana sin guardar ningun cambio
     *
     * ES LLAMADO POR: actionPerformed cuando detecta btnCancelar
     */
    public void accionCancelar() {
        dispose(); // cierra solo esta ventana sin guardar
    }
}