package Ventanas;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.SystemColor;

/*
 * VENTANA LOGIN
 * Esta ventana solicita al usuario que ingrese
 * su usuario y contraseña para acceder al sistema
 * Si los datos son correctos abre la ventana Ven_Archivo
 * Si los datos son incorrectos muestra un mensaje de error
 */
public class Ven_Login extends JFrame implements ActionListener {

    private static final long serialVersionUID = 1L;

    // ---- COMPONENTES DE LA VENTANA ----
    private JPanel contentPane;       // panel principal de la ventana
    private JLabel lblNewLabel;       // etiqueta del titulo principal
    private JLabel lblNewLabel_1;     // etiqueta que dice "Usuario:"
    private JLabel lblNewLabel_2;     // etiqueta que dice "Contraseña:"
    private JTextField TxtUsuario;    // campo donde el usuario escribe su nombre
    private JPasswordField TxtPassword; // campo donde escribe su contraseña (oculta con *)
    private JButton btnCancelar;      // boton para limpiar los campos
    private JButton BtnAceptar;       // boton para validar e ingresar al sistema

    // ---- VARIABLES GLOBALES ----
    // son publicas y estaticas para que otras ventanas puedan usarlas
    public static String usario;    // guarda el nombre de usuario ingresado
    public static String contraseña; // guarda la contraseña ingresada

    /*
     * METODO MAIN
     * Es el punto de inicio cuando ejecutamos esta ventana directamente
     * Crea una instancia de Ven_Login y la hace visible
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    // crea la ventana y la muestra
                    Ven_Login frame = new Ven_Login();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /*
     * CONSTRUCTOR - Ven_Login()
     * Se ejecuta automaticamente cuando hacemos:
     *    Ven_Login frame = new Ven_Login();
     * Aqui se crean y acomodan todos los componentes
     * de la ventana (labels, textfields, botones)
     */
    public Ven_Login() {
        setTitle("Login"); // titulo de la ventana
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // al cerrar termina el programa
        setBounds(100, 100, 579, 377);  // posicion x, y y tamaño ancho, alto
        setLocationRelativeTo(null);    // centra la ventana en la pantalla

        // configuracion del panel principal
        contentPane = new JPanel();
        contentPane.setBackground(SystemColor.inactiveCaptionBorder); // color de fondo
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5)); // margen interno
        setContentPane(contentPane);
        contentPane.setLayout(null); // posicion manual de componentes

        // -- etiqueta titulo principal --
        lblNewLabel = new JLabel("Ingrese Usuario y Contraseña");
        lblNewLabel.setFont(new Font("Times New Roman", Font.PLAIN, 25));
        lblNewLabel.setBounds(114, 59, 404, 48);
        contentPane.add(lblNewLabel);

        // -- etiqueta "Usuario:" --
        lblNewLabel_1 = new JLabel("Usuario:");
        lblNewLabel_1.setHorizontalAlignment(SwingConstants.RIGHT); // alineado a la derecha
        lblNewLabel_1.setBounds(119, 174, 73, 12);
        contentPane.add(lblNewLabel_1);

        // -- etiqueta "Contraseña:" --
        lblNewLabel_2 = new JLabel("Contraseña:");
        lblNewLabel_2.setHorizontalAlignment(SwingConstants.RIGHT);
        lblNewLabel_2.setBounds(95, 227, 97, 12);
        contentPane.add(lblNewLabel_2);

        // -- campo de texto para el usuario --
        TxtUsuario = new JTextField();
        TxtUsuario.setBounds(252, 168, 119, 18);
        contentPane.add(TxtUsuario);
        TxtUsuario.setColumns(10); // ancho del campo en caracteres

        // -- campo de contraseña (muestra * en vez de letras) --
        TxtPassword = new JPasswordField();
        TxtPassword.setBounds(252, 221, 119, 18);
        contentPane.add(TxtPassword);

        // -- boton Cancelar --
        btnCancelar = new JButton("Cancelar");
        btnCancelar.addActionListener(this); // llama a actionPerformed al presionar
        btnCancelar.setBounds(108, 282, 84, 20);
        contentPane.add(btnCancelar);

        // -- boton Aceptar --
        BtnAceptar = new JButton("Aceptar");
        BtnAceptar.addActionListener(this); // llama a actionPerformed al presionar
        BtnAceptar.setBounds(332, 282, 84, 20);
        contentPane.add(BtnAceptar);
    }

    /*
     * METODO actionPerformed (VOID)
     * Se ejecuta automaticamente cuando el usuario presiona un boton
     * Detecta cual boton fue presionado con e.getSource()
     * y llama al metodo correspondiente
     *
     * ES LLAMADO POR: BtnAceptar y btnCancelar
     *                 (ambos tienen addActionListener(this))
     */
    public void actionPerformed(ActionEvent e) {

        // si se presiono el boton Aceptar
        if (e.getSource() == BtnAceptar) {
            actionPerformedBtnAceptar(e); // llama al metodo de validacion
        }

        // si se presiono el boton Cancelar
        if (e.getSource() == btnCancelar) {
            actionPerformedBtnCancelar(e); // llama al metodo de limpiar campos
        }
    }

    /*
     * METODO actionPerformedBtnCancelar (VOID)
     * Limpia los campos de usuario y contraseña
     * y coloca el cursor en el campo de usuario
     * NO cierra la ventana, solo borra lo escrito
     *
     * ES LLAMADO POR: actionPerformed cuando detecta btnCancelar
     * PARAMETRO: e = evento que genero la accion
     */
    protected void actionPerformedBtnCancelar(ActionEvent e) {
        TxtUsuario.setText("");      // limpia el campo de usuario
        TxtPassword.setText("");     // limpia el campo de contraseña
        TxtUsuario.requestFocus();   // mueve el cursor al campo de usuario
    }

    /*
     * METODO actionPerformedBtnAceptar (VOID)
     * Lee el usuario y contraseña escritos
     * Verifica si son correctos:
     *   - Si son correctos: muestra mensaje de bienvenida
     *                       abre Ven_Archivo y cierra el login
     *   - Si son incorrectos: muestra mensaje de error
     *                         limpia los campos y pone el cursor en usuario
     *
     * ES LLAMADO POR: actionPerformed cuando detecta BtnAceptar
     * PARAMETRO: e = evento que genero la accion
     */
    protected void actionPerformedBtnAceptar(ActionEvent e) {

        // lee lo que el usuario escribio en los campos
        usario    = TxtUsuario.getText();
        contraseña = TxtPassword.getText(); // getText() muestra el texto oculto

        // verifica si el usuario y contraseña son correctos
        // usuario correcto: Admin
        // contraseña correcta: 123456
        if (usario.equals("Admin") && contraseña.equals("123456")) {

            // si los datos son correctos muestra mensaje de bienvenida
            JOptionPane.showMessageDialog(null,
                "Bienvenido al Sistema",
                "Acceso Correcto",
                JOptionPane.INFORMATION_MESSAGE);

            // abre la ventana principal del sistema
            Ven_Archivo va = new Ven_Archivo();
            va.setVisible(true);

            // cierra la ventana de login
            // Ven_Login.this hace referencia a esta misma ventana
            Ven_Login.this.dispose();

        } else {

            // si los datos son incorrectos muestra mensaje de error
            JOptionPane.showMessageDialog(null,
                "Usuario o contraseña incorrectos",
                "Error de acceso",
                JOptionPane.ERROR_MESSAGE);

            // limpia los campos para que el usuario vuelva a intentar
            TxtUsuario.setText("");
            TxtPassword.setText("");
            TxtUsuario.requestFocus(); // mueve el cursor al campo usuario
        }
    }
}