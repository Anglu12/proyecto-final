package Ventanas;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class Ven_ConsultarCocina extends JFrame implements ActionListener {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField TxtPrecio, TxtAncho, TxtAlto, TxtFondo;
    private JComboBox<String> cboModeloCocina;
    private JButton btnCerrar;
  
    
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Ven_ConsultarCocina frame = new Ven_ConsultarCocina();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public Ven_ConsultarCocina() {
        setTitle("Consultar Cocina");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 450, 300);
        setLocationRelativeTo(null);
        setResizable(false);

        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setLayout(null);
        setContentPane(contentPane);

        JLabel lblModelo = new JLabel("Modelo:");
        lblModelo.setBounds(57, 46, 76, 12);
        contentPane.add(lblModelo);

        cboModeloCocina = new JComboBox<>(new String[]{
            "Cocina Indurama Quarzo",
            "Cocina Mabe EM6010",
            "Cocina Coldex CG560",
            "Cocina Surge Premium",
            "Cocina Miray CG560G"
        });
        cboModeloCocina.setBounds(143, 42, 165, 20);
        cboModeloCocina.addActionListener(this);
        contentPane.add(cboModeloCocina);

        JLabel lblPrecio = new JLabel("Precio (S/):");
        lblPrecio.setBounds(57, 87, 80, 12);
        contentPane.add(lblPrecio);

        TxtPrecio = new JTextField();
        TxtPrecio.setEditable(false);
        TxtPrecio.setBounds(143, 84, 165, 18);
        contentPane.add(TxtPrecio);

        JLabel lblAncho = new JLabel("Ancho (cm):");
        lblAncho.setBounds(57, 116, 80, 12);
        contentPane.add(lblAncho);

        TxtAncho = new JTextField();
        TxtAncho.setEditable(false);
        TxtAncho.setBounds(143, 113, 165, 18);
        contentPane.add(TxtAncho);

        JLabel lblAlto = new JLabel("Alto (cm):");
        lblAlto.setBounds(57, 146, 80, 12);
        contentPane.add(lblAlto);

        TxtAlto = new JTextField();
        TxtAlto.setEditable(false);
        TxtAlto.setBounds(143, 143, 165, 18);
        contentPane.add(TxtAlto);

        JLabel lblFondo = new JLabel("Fondo (cm):");
        lblFondo.setBounds(57, 176, 80, 12);
        contentPane.add(lblFondo);

        TxtFondo = new JTextField();
        TxtFondo.setEditable(false);
        TxtFondo.setBounds(143, 173, 165, 18);
        contentPane.add(TxtFondo);

        btnCerrar = new JButton("Cerrar");
        btnCerrar.setBounds(342, 42, 84, 20);
        btnCerrar.addActionListener(this);
        contentPane.add(btnCerrar);

        getDatos(0);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnCerrar) {
            dispose();
        }
        if (e.getSource() == cboModeloCocina) {
            getDatos(cboModeloCocina.getSelectedIndex());
        }
    }

    public void getDatos(int modelo) {
        switch (modelo) {
            case 0:
                TxtPrecio.setText(String.valueOf(Ven_Principal.precio0));
                TxtAncho.setText(String.valueOf(Ven_Principal.ancho0));
                TxtAlto.setText(String.valueOf(Ven_Principal.alto0));
                TxtFondo.setText(String.valueOf(Ven_Principal.fondo0));
                break;
            case 1:
                TxtPrecio.setText(String.valueOf(Ven_Principal.precio1));
                TxtAncho.setText(String.valueOf(Ven_Principal.ancho1));
                TxtAlto.setText(String.valueOf(Ven_Principal.alto1));
                TxtFondo.setText(String.valueOf(Ven_Principal.fondo1));
                break;
            case 2:
                TxtPrecio.setText(String.valueOf(Ven_Principal.precio2));
                TxtAncho.setText(String.valueOf(Ven_Principal.ancho2));
                TxtAlto.setText(String.valueOf(Ven_Principal.alto2));
                TxtFondo.setText(String.valueOf(Ven_Principal.fondo2));
                break;
            case 3:
                TxtPrecio.setText(String.valueOf(Ven_Principal.precio3));
                TxtAncho.setText(String.valueOf(Ven_Principal.ancho3));
                TxtAlto.setText(String.valueOf(Ven_Principal.alto3));
                TxtFondo.setText(String.valueOf(Ven_Principal.fondo3));
                break;
            default:
                TxtPrecio.setText(String.valueOf(Ven_Principal.precio4));
                TxtAncho.setText(String.valueOf(Ven_Principal.ancho4));
                TxtAlto.setText(String.valueOf(Ven_Principal.alto4));
                TxtFondo.setText(String.valueOf(Ven_Principal.fondo4));
                break;
        }
    }
}