package Ventanas;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

/*
 * VENTANA VENDER
 * Esta ventana permite realizar ventas de cocinas
 * Calcula automaticamente:
 *   - Importe de compra (precio x cantidad)
 *   - Importe de descuento (segun tabla de porcentajes)
 *   - Importe a pagar (compra - descuento)
 *   - Obsequio (segun tabla de obsequios)
 * Cada 5 ventas muestra un mensaje de avance de ventas
 */
public class Ven_VentasCocina extends JFrame implements ActionListener {

    private static final long serialVersionUID = 1L;

    // ---- COMPONENTES DE LA VENTANA ----
    private JPanel contentPane;
    private JComboBox<String> cboModelo;  // lista de modelos de cocina
    private JTextField TxtPrecio;         // muestra el precio (no editable)
    private JTextField TxtCantidad;       // el usuario escribe la cantidad
    private JTextArea txtBoleta;          // muestra la boleta de venta
    private JButton btnVender;            // boton para realizar la venta
    private JButton btnCerrar;            // boton para cerrar la ventana

    // ---- CONTADOR Y ACUMULADOR ----
    // estas variables son estaticas para que no se reseteen al abrir la ventana
    private static int contadorVentas = 0;        // cuenta cuantas ventas se han hecho
    private static double acumuladorTotal = 0.0;  // suma todos los importes a pagar

    // ---- CUOTA DIARIA ----
    // valor fijo que representa la meta de ventas del dia
    private static double cuotaDiaria = 50000.0;

    /*
     * METODO MAIN
     * Solo se usa para probar esta ventana directamente
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Ven_VentasCocina frame = new Ven_VentasCocina();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /*
     * CONSTRUCTOR - Ven_Vender()
     * Crea todos los componentes de la ventana
     * Al final llama a mostrarPrecio() para mostrar
     * el precio de la primera cocina del combo
     */
    public Ven_VentasCocina() {
        setTitle("Vender");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 480, 420);
        setLocationRelativeTo(null);
        setResizable(false);

        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setLayout(null);
        setContentPane(contentPane);

        // -- etiqueta y combo de modelo --
        JLabel lblModelo = new JLabel("Modelo:");
        lblModelo.setBounds(20, 20, 80, 20);
        contentPane.add(lblModelo);

        cboModelo = new JComboBox<String>();
        cboModelo.addItem("Cocina Indurama Quarzo"); // indice 0
        cboModelo.addItem("Cocina Mabe EM6010");     // indice 1
        cboModelo.addItem("Cocina Coldex CG560");    // indice 2
        cboModelo.addItem("Cocina Surge Premium");   // indice 3
        cboModelo.addItem("Cocina Miray CG560G");    // indice 4
        cboModelo.setBounds(110, 18, 200, 22);
        cboModelo.addActionListener(this);
        contentPane.add(cboModelo);

        // -- etiqueta y campo de precio (no editable) --
        JLabel lblPrecio = new JLabel("Precio(S/):");
        lblPrecio.setBounds(20, 55, 80, 20);
        contentPane.add(lblPrecio);

        TxtPrecio = new JTextField();
        TxtPrecio.setEditable(false); // el precio no se puede modificar
        TxtPrecio.setBounds(110, 53, 200, 22);
        contentPane.add(TxtPrecio);

        // -- etiqueta y campo de cantidad --
        JLabel lblCantidad = new JLabel("Cantidad:");
        lblCantidad.setBounds(20, 90, 80, 20);
        contentPane.add(lblCantidad);

        TxtCantidad = new JTextField();
        TxtCantidad.setBounds(110, 88, 200, 22);
        contentPane.add(TxtCantidad);

        // -- area de texto para la boleta con scroll --
        txtBoleta = new JTextArea();
        txtBoleta.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(txtBoleta);
        scrollPane.setBounds(20, 125, 430, 220);
        contentPane.add(scrollPane);

        // -- boton Vender --
        btnVender = new JButton("Vender");
        btnVender.setBounds(360, 18, 90, 25);
        btnVender.addActionListener(this);
        contentPane.add(btnVender);

        // -- boton Cerrar --
        btnCerrar = new JButton("Cerrar");
        btnCerrar.setBounds(360, 53, 90, 25);
        btnCerrar.addActionListener(this);
        contentPane.add(btnCerrar);

        // al abrir muestra el precio de la primera cocina
        mostrarPrecio(0);
    }

    /*
     * METODO actionPerformed (VOID)
     * Detecta que boton o combo fue activado
     * y llama al metodo correspondiente
     *
     * ES LLAMADO POR: cboModelo, btnVender, btnCerrar
     */
    public void actionPerformed(ActionEvent e) {

        // si cambio el combo muestra el precio del modelo seleccionado
        if (e.getSource() == cboModelo) {
            mostrarPrecio(cboModelo.getSelectedIndex());
        }

        // si presiono Vender realiza la venta
        if (e.getSource() == btnVender) {
            accionVender();
        }

        // si presiono Cerrar cierra la ventana
        if (e.getSource() == btnCerrar) {
            accionCerrar();
        }
    }

    /*
     * METODO mostrarPrecio (VOID)
     * Muestra el precio de la cocina seleccionada
     * en el campo TxtPrecio (no editable)
     *
     * ES LLAMADO POR: constructor y actionPerformed cuando cambia el combo
     * PARAMETRO: indice = numero de la cocina en el combo (0,1,2,3,4)
     */
    public void mostrarPrecio(int indice) {
        if (indice == 0) {
            TxtPrecio.setText(String.valueOf(Ven_Principal.precio0));
        }
        if (indice == 1) {
            TxtPrecio.setText(String.valueOf(Ven_Principal.precio1));
        }
        if (indice == 2) {
            TxtPrecio.setText(String.valueOf(Ven_Principal.precio2));
        }
        if (indice == 3) {
            TxtPrecio.setText(String.valueOf(Ven_Principal.precio3));
        }
        if (indice == 4) {
            TxtPrecio.setText(String.valueOf(Ven_Principal.precio4));
        }
    }

    /*
     * METODO obtenerPrecio (RETORNA double)
     * Lee el precio del campo TxtPrecio
     * y lo convierte a numero decimal
     *
     * ES LLAMADO POR: accionVender
     * RETORNA: el precio como numero double
     */
    public double obtenerPrecio() {
        double valor = Double.parseDouble(TxtPrecio.getText());
        return valor;
    }

    /*
     * METODO obtenerCantidad (RETORNA int)
     * Lee la cantidad escrita por el usuario
     * y la convierte a numero entero
     *
     * ES LLAMADO POR: accionVender
     * RETORNA: la cantidad como numero entero
     */
    public int obtenerCantidad() {
        int valor = Integer.parseInt(TxtCantidad.getText());
        return valor;
    }

    /*
     * METODO calcularImporteCompra (RETORNA double)
     * Multiplica el precio por la cantidad
     * para obtener el importe total de compra
     *
     * ES LLAMADO POR: accionVender
     * RETORNA: precio x cantidad
     */
    public double calcularImporteCompra(double precio, int cantidad) {
        double importeCompra = precio * cantidad;
        return importeCompra;
    }

    /*
     * METODO calcularDescuento (RETORNA double)
     * Calcula el porcentaje de descuento segun la cantidad
     * usando la tabla de porcentajes de Ven_ConfigurarDescuentos
     *
     * ES LLAMADO POR: accionVender
     * RETORNA: el porcentaje de descuento que corresponde
     */
    public double calcularDescuento(int cantidad) {
        double porcentaje = 0;

        if (cantidad >= 1 && cantidad <= 5) {
            porcentaje = Ven_ConfigurarDescuento.porcentaje1; // 1 a 5 unidades
        }
        if (cantidad >= 6 && cantidad <= 10) {
            porcentaje = Ven_ConfigurarDescuento.porcentaje2; // 6 a 10 unidades
        }
        if (cantidad >= 11 && cantidad <= 15) {
            porcentaje = Ven_ConfigurarDescuento.porcentaje3; // 11 a 15 unidades
        }
        if (cantidad > 15) {
            porcentaje = Ven_ConfigurarDescuento.porcentaje4; // mas de 15 unidades
        }

        return porcentaje;
    }

    /*
     * METODO calcularImporteDescuento (RETORNA double)
     * Calcula cuanto dinero se descuenta
     * usando el importe de compra y el porcentaje
     *
     * ES LLAMADO POR: accionVender
     * RETORNA: el monto del descuento en soles
     */
    public double calcularImporteDescuento(double importeCompra, double porcentaje) {
        double importeDescuento = importeCompra * porcentaje / 100;
        return importeDescuento;
    }

    /*
     * METODO calcularImportePagar (RETORNA double)
     * Resta el descuento al importe de compra
     *
     * ES LLAMADO POR: accionVender
     * RETORNA: el importe final a pagar
     */
    public double calcularImportePagar(double importeCompra, double importeDescuento) {
        double importePagar = importeCompra - importeDescuento;
        return importePagar;
    }

    /*
     * METODO obtenerObsequio (RETORNA String)
     * Determina que obsequio corresponde segun la cantidad
     * usando la tabla de obsequios de Ven_ConfigurarObsequios
     *
     * ES LLAMADO POR: accionVender
     * RETORNA: el nombre del obsequio que corresponde
     */
    public String obtenerObsequio(int cantidad) {
        String obsequio = "";

        if (cantidad == 1) {
            obsequio = Ven_ConfigurarObsequios.obsequio1; // 1 unidad
        }
        if (cantidad >= 2 && cantidad <= 5) {
            obsequio = Ven_ConfigurarObsequios.obsequio2; // 2 a 5 unidades
        }
        if (cantidad > 5) {
            obsequio = Ven_ConfigurarObsequios.obsequio3; // mas de 5 unidades
        }

        return obsequio;
    }

    /*
     * METODO mostrarBoleta (VOID)
     * Arma y muestra la boleta de venta en el JTextArea
     * con todos los datos de la venta realizada
     *
     * ES LLAMADO POR: accionVender
     */
    public void mostrarBoleta(String modelo, double precio, int cantidad,
                               double importeCompra, double importeDescuento,
                               double importePagar, String obsequio) {

        String boleta = "";
        boleta += "BOLETA DE VENTA\n";
        boleta += "\n";
        boleta += "Modelo           : " + modelo + "\n";
        boleta += "Precio           : S/. " + precio + "\n";
        boleta += "Cantidad         : " + cantidad + "\n";
        boleta += "Importe Compra   : S/. " + importeCompra + "\n";
        boleta += "Importe Descuento: S/. " + importeDescuento + "\n";
        boleta += "Importe a Pagar  : S/. " + importePagar + "\n";
        boleta += "Obsequio         : " + obsequio + "\n";

        txtBoleta.setText(boleta);
    }

    /*
     * METODO mostrarAvanceVentas (VOID)
     * Muestra un mensaje cada 5 ventas con:
     *   - Numero de venta actual
     *   - Importe total acumulado
     *   - Porcentaje de la cuota diaria
     *
     * ES LLAMADO POR: accionVender cuando contadorVentas es multiplo de 5
     */
    public void mostrarAvanceVentas() {

        // calcula el porcentaje de la cuota diaria alcanzado
        double porcentajeCuota = (acumuladorTotal / cuotaDiaria) * 100;

        // arma el mensaje
        String mensaje = "";
        mensaje += "Venta Nro. " + contadorVentas + "\n";
        mensaje += "Importe total general acumulado : S/. " + 
                   String.format("%.2f", acumuladorTotal) + "\n";
        mensaje += "Porcentaje de la cuota diaria : " + 
                   String.format("%.2f", porcentajeCuota) + "%";

        // muestra el mensaje en una ventana de informacion
        JOptionPane.showMessageDialog(null,
            mensaje,
            "Avance de ventas",
            JOptionPane.INFORMATION_MESSAGE);
    }

    /*
     * METODO accionVender (VOID)
     * Es el metodo principal que realiza toda la venta
     * Llama a todos los metodos de calculo en orden:
     *   1. obtenerPrecio y obtenerCantidad
     *   2. calcularImporteCompra
     *   3. calcularDescuento y calcularImporteDescuento
     *   4. calcularImportePagar
     *   5. obtenerObsequio
     *   6. mostrarBoleta
     *   7. actualiza contador y acumulador
     *   8. cada 5 ventas llama a mostrarAvanceVentas
     *
     * ES LLAMADO POR: actionPerformed cuando detecta btnVender
     */
    public void accionVender() {
        try {
            // paso 1: obtiene precio y cantidad
            double precio    = obtenerPrecio();
            int cantidad     = obtenerCantidad();

            // verifica que la cantidad sea mayor a 0
            if (cantidad <= 0) {
                JOptionPane.showMessageDialog(null,
                    "La cantidad debe ser mayor a 0",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
                return;
            }

            // paso 2: calcula importe de compra
            double importeCompra = calcularImporteCompra(precio, cantidad);

            // paso 3: calcula porcentaje e importe de descuento
            double porcentaje       = calcularDescuento(cantidad);
            double importeDescuento = calcularImporteDescuento(importeCompra, porcentaje);

            // paso 4: calcula importe a pagar
            double importePagar = calcularImportePagar(importeCompra, importeDescuento);

            // paso 5: obtiene el obsequio segun cantidad
            String obsequio = obtenerObsequio(cantidad);

            // paso 6: obtiene el nombre del modelo seleccionado
            String modelo = (String) cboModelo.getSelectedItem();

            // paso 7: muestra la boleta en el JTextArea
            mostrarBoleta(modelo, precio, cantidad,
                          importeCompra, importeDescuento,
                          importePagar, obsequio);

            // paso 8: actualiza el contador y acumulador
            contadorVentas++;               // suma 1 al contador de ventas
            acumuladorTotal += importePagar; // suma el importe al acumulador

            // paso 9: cada 5 ventas muestra el avance
            if (contadorVentas % 5 == 0) {
                mostrarAvanceVentas();
            }

        } catch (NumberFormatException ex) {
            // si el usuario escribio letras en cantidad muestra error
            JOptionPane.showMessageDialog(null,
                "Por favor ingrese un numero valido en Cantidad",
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    /*
     * METODO accionCerrar (VOID)
     * Cierra solo esta ventana
     *
     * ES LLAMADO POR: actionPerformed cuando detecta btnCerrar
     */
    public void accionCerrar() {
        dispose();
    }
}