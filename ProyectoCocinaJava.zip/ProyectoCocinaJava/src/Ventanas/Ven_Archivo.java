package Ventanas;

import java.awt.EventQueue;
import java.awt.event.ActionEvent; // se agrego para la ventana salir estos import//
import java.awt.event.ActionListener; // se agrego para la ventana salir estos import//

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import java.awt.SystemColor;

public class Ven_Archivo extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JMenuBar menuBar;
	private JMenu mnNewMenu;
	private JMenu mnNewMenu_1;
	private JMenu mnNewMenu_2;
	private JMenu mnNewMenu_3;
	private JMenu mnNewMenu_4;
	private JMenuItem mntmNewMenuItem;
	private JMenuItem mntmNewMenuItem_1;
	private JMenuItem mntmNewMenuItem_2;
	private JMenuItem mntmNewMenuItem_3;
	private JMenuItem mntmNewMenuItem_4;
	private JMenuItem mntmNewMenuItem_5;
	private JMenuItem mntmNewMenuItem_6;
	private JMenuItem mntmNewMenuItem_7;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {	
				try {
					Ven_Archivo frame = new Ven_Archivo();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}	
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Ven_Archivo() {
		setTitle("Software Principal");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		this.setLocationRelativeTo(null); // Para centrar todo las ventanas //
		
		// ---- MENU BAR ----
		menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		mnNewMenu = new JMenu("Archivo");
		menuBar.add(mnNewMenu);
		
		mntmNewMenuItem = new JMenuItem("Salir");
		mnNewMenu.add(mntmNewMenuItem);
		
		// ---- Configuración boton salir // 
		mntmNewMenuItem.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        System.exit(0);
		    }
		});
		
		mnNewMenu_1 = new JMenu("Mantenimiento");
		menuBar.add(mnNewMenu_1);
		
		mntmNewMenuItem_1 = new JMenuItem("Consultar Cocina");
		mnNewMenu_1.add(mntmNewMenuItem_1);
		mntmNewMenuItem_1.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        Ven_ConsultarCocina vc = new Ven_ConsultarCocina();
		        vc.setVisible(true);
		    }
		});
		
		mntmNewMenuItem_2 = new JMenuItem("Modificar Cocina");
		mnNewMenu_1.add(mntmNewMenuItem_2);
		mntmNewMenuItem_2.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        Ven_ModificarCocina vm = new Ven_ModificarCocina();
		        vm.setVisible(true);
		    }
		});
		
		mntmNewMenuItem_3 = new JMenuItem("Listar Cocina");
		mnNewMenu_1.add(mntmNewMenuItem_3);
		
		// ✅ AGREGA ESTO
		mntmNewMenuItem_3.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        Ven_ListarCocinas vl = new Ven_ListarCocinas();
		        vl.setVisible(true);
		    }
		});
		
		mnNewMenu_2 = new JMenu("Ventas");
		menuBar.add(mnNewMenu_2);
		
		mntmNewMenuItem_4 = new JMenuItem("Vender");
		mnNewMenu_2.add(mntmNewMenuItem_4);
		mntmNewMenuItem_4.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        Ven_VentasCocina vv = new Ven_VentasCocina();
		        vv.setVisible(true);
		    }	
		});
		
		mnNewMenu_3 = new JMenu("Configuración");
		menuBar.add(mnNewMenu_3);
		
		mntmNewMenuItem_5 = new JMenuItem("Configuración Descuento");
		mnNewMenu_3.add(mntmNewMenuItem_5);
		
		mntmNewMenuItem_5.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        Ven_ConfigurarDescuento vd = new Ven_ConfigurarDescuento();
		        vd.setVisible(true);
		    }
		});	
		
		mntmNewMenuItem_6 = new JMenuItem("Configuración Obsequio");
		mnNewMenu_3.add(mntmNewMenuItem_6);	
		mntmNewMenuItem_6.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        Ven_ConfigurarObsequios vo = new Ven_ConfigurarObsequios();
		        vo.setVisible(true);
		    }
		});
		
		mnNewMenu_4 = new JMenu("Ayuda");
		menuBar.add(mnNewMenu_4);
		
		mntmNewMenuItem_7 = new JMenuItem("Acerca de la Tienda");
		mnNewMenu_4.add(mntmNewMenuItem_7);
		contentPane = new JPanel();
		contentPane.setForeground(SystemColor.activeCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		mntmNewMenuItem_7.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        Ven_AcercaTienda va = new Ven_AcercaTienda();
		        va.setVisible(true);
		    }
		});

	}
}
