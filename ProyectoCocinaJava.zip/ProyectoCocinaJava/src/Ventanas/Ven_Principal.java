package Ventanas;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import Ventanas.Ven_Principal;

public class Ven_Principal extends JFrame {

	// Datos de la primera cocina // 
    public static String modelo0 = "Cocina Indurama Quarzo";
    public static double precio0 = 1299.0;	
    public static double ancho0 = 60.0;
    public static double alto0 = 85.0;
    public static double fondo0 = 60.0;
    public static int quemadores0 = 4;

    // Datos de la segunda cocina // 
    public static String modelo1 = "Cocina Mabe EM6010";
    public static double precio1 = 980.0;
    public static double ancho1 = 60.0;
    public static double alto1 = 85.0;
    public static double fondo1 = 60.0;
    public static int quemadores1 = 4;

    // Datos de la tercera cocina // 
    public static String modelo2 = "Cocina Coldex CG560";
    public static double precio2 = 750.0;
    public static double ancho2 = 55.0;
    public static double alto2 = 80.0;
    public static double fondo2 = 55.0;
    public static int quemadores2 = 4;

    // Datos de la cuarta cocina // 
    public static String modelo3 = "Cocina Surge Premium";
    public static double precio3 = 1150.0;
    public static double ancho3 = 60.0;
    public static double alto3 = 85.0;
    public static double fondo3 = 60.0;
    public static int quemadores3 = 5;

    // Datos de la quinta cocina // 
    public static String modelo4 = "Cocina Miray CG560G";
    public static double precio4 = 599.0;
    public static double ancho4 = 50.0;
    public static double alto4 = 78.0;
    public static double fondo4 = 50.0;
    public static int quemadores4 = 4;
    
 // Porcentajes de descuento 
    public static double porcentaje1 = 7.5; 
    public static double porcentaje2 = 10.0; 
    public static double porcentaje3 = 12.5; 
    public static double porcentaje4 = 15.0; 
    // Obsequios 
    public static String obsequio1 = "Cafetera"; 
    public static String obsequio2 = "Licuadora"; 
    public static String obsequio3 = "Extractor"; 

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Ven_Principal frame = new Ven_Principal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Ven_Principal() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		setLocationRelativeTo(null); // Para centrar todo las ventanas //
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);

	}

}
