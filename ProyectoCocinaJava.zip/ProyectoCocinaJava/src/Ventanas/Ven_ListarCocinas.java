package Ventanas;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class Ven_ListarCocinas extends JFrame implements ActionListener {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextArea txtArea;
    private JButton btnCerrar, btnListar;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Ven_ListarCocinas frame = new Ven_ListarCocinas();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public Ven_ListarCocinas() {
        setTitle("Listado de Cocinas");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 450, 400);
        setLocationRelativeTo(null);
        setResizable(false);

        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setLayout(null);
        setContentPane(contentPane);

        //  AREA DE TEXTO CON SCROLL
        txtArea = new JTextArea();
        txtArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(txtArea);
        scrollPane.setBounds(10, 10, 415, 300);
        contentPane.add(scrollPane);

        // BOTONES
        btnCerrar = new JButton("Cerrar");
        btnCerrar.setBounds(100, 325, 100, 25);
        btnCerrar.addActionListener(this);
        contentPane.add(btnCerrar);

        btnListar = new JButton("Listar");
        btnListar.setBounds(250, 325, 100, 25);
        btnListar.addActionListener(this);
        contentPane.add(btnListar);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnCerrar) {
            dispose();
        }
        if (e.getSource() == btnListar) {
            listarCocinas();
        }
    }

    //  Muestra todas las cocinas en el JTextArea
    public void listarCocinas() {
        String listado = "";
        listado += "LISTADO DE COCINAS\n";
        listado += "==========================================\n\n";

        listado += "Modelo      : " + Ven_Principal.modelo0 + "\n";
        listado += "Precio      : S/. " + Ven_Principal.precio0 + "\n";
        listado += "Ancho       : " + Ven_Principal.ancho0 + " cm\n";
        listado += "Alto        : " + Ven_Principal.alto0 + " cm\n";
        listado += "Fondo       : " + Ven_Principal.fondo0 + " cm\n";
        listado += "Quemadores  : " + Ven_Principal.quemadores0 + "\n\n";

        listado += "Modelo      : " + Ven_Principal.modelo1 + "\n";
        listado += "Precio      : S/. " + Ven_Principal.precio1 + "\n";
        listado += "Ancho       : " + Ven_Principal.ancho1 + " cm\n";
        listado += "Alto        : " + Ven_Principal.alto1 + " cm\n";
        listado += "Fondo       : " + Ven_Principal.fondo1 + " cm\n";
        listado += "Quemadores  : " + Ven_Principal.quemadores1 + "\n\n";

        listado += "Modelo      : " + Ven_Principal.modelo2 + "\n";
        listado += "Precio      : S/. " + Ven_Principal.precio2 + "\n";
        listado += "Ancho       : " + Ven_Principal.ancho2 + " cm\n";
        listado += "Alto        : " + Ven_Principal.alto2 + " cm\n";
        listado += "Fondo       : " + Ven_Principal.fondo2 + " cm\n";
        listado += "Quemadores  : " + Ven_Principal.quemadores2 + "\n\n";

        listado += "Modelo      : " + Ven_Principal.modelo3 + "\n";
        listado += "Precio      : S/. " + Ven_Principal.precio3 + "\n";
        listado += "Ancho       : " + Ven_Principal.ancho3 + " cm\n";
        listado += "Alto        : " + Ven_Principal.alto3 + " cm\n";
        listado += "Fondo       : " + Ven_Principal.fondo3 + " cm\n";
        listado += "Quemadores  : " + Ven_Principal.quemadores3 + "\n\n";

        listado += "Modelo      : " + Ven_Principal.modelo4 + "\n";
        listado += "Precio      : S/. " + Ven_Principal.precio4 + "\n";
        listado += "Ancho       : " + Ven_Principal.ancho4 + " cm\n";
        listado += "Alto        : " + Ven_Principal.alto4 + " cm\n";
        listado += "Fondo       : " + Ven_Principal.fondo4 + " cm\n";
        listado += "Quemadores  : " + Ven_Principal.quemadores4 + "\n\n";

        txtArea.setText(listado);
        
    }
    
}