package Ventanas;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.SystemColor;

/*
 * VENTANA INGRESAR USUARIO
 * Esta es la primera ventana que ve el usuario al iniciar el programa
 * Muestra un mensaje de bienvenida y dos botones:
 *   - INGRESAR: abre la ventana de Login para validar usuario y contraseña
 *   - SALIR: cierra completamente el programa
 */
public class Ven_IngresarUsuario extends JFrame implements ActionListener {

    private static final long serialVersionUID = 1L;

    // ---- COMPONENTES DE LA VENTANA ----
    private JPanel contentPane;   // panel principal de la ventana
    private JLabel lblNewLabel;   // etiqueta con el mensaje de bienvenida
    private JButton btnIngresar;  // boton para ir a la ventana de login
    private JButton btnSalir;     // boton para cerrar el programa

    /*
     * METODO MAIN
     * Es el punto de inicio de todo el programa
     * Es el primer metodo que se ejecuta cuando arranca la aplicacion
     * Crea una instancia de Ven_IngresarUsuario y la hace visible
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    // crea la ventana de bienvenida y la muestra
                    Ven_IngresarUsuario frame = new Ven_IngresarUsuario();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /*
     * CONSTRUCTOR - Ven_IngresarUsuario()
     * Se ejecuta automaticamente cuando hacemos:
     *    Ven_IngresarUsuario frame = new Ven_IngresarUsuario();
     * Aqui se crean y acomodan todos los componentes
     * de la ventana (label de bienvenida y los dos botones)
     */
    public Ven_IngresarUsuario() {
        setTitle("Inicio"); // titulo que aparece en la barra de la ventana
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE); // la X no hace nada
        setBounds(100, 100, 638, 430);  // posicion x, y y tamaño ancho, alto
        setLocationRelativeTo(null);    // centra la ventana en la pantalla

        // configuracion del panel principal
        contentPane = new JPanel();
        contentPane.setForeground(SystemColor.activeCaption); // color del texto
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));   // margen interno
        setContentPane(contentPane);
        contentPane.setLayout(null); // posicion manual de los componentes

        // -- etiqueta de bienvenida --
        lblNewLabel = new JLabel("Bienvenido al Sistema de Ventas");
        lblNewLabel.setFont(new Font("Times New Roman", Font.ITALIC, 22)); // fuente cursiva
        lblNewLabel.setBounds(137, 84, 336, 44); // posicion y tamaño del label
        contentPane.add(lblNewLabel);

        // -- boton INGRESAR --
        // al presionarlo abre la ventana de login
        btnIngresar = new JButton("INGRESAR");
        btnIngresar.addActionListener(this); // llama a actionPerformed al presionar
        btnIngresar.setBounds(137, 270, 115, 20);
        contentPane.add(btnIngresar);

        // -- boton SALIR --
        // al presionarlo cierra completamente el programa
        btnSalir = new JButton("SALIR");
        btnSalir.addActionListener(this); // llama a actionPerformed al presionar
        btnSalir.setBounds(378, 270, 84, 20);
        contentPane.add(btnSalir);
    }

    /*
     * METODO actionPerformed (VOID)
     * Se ejecuta automaticamente cuando el usuario presiona un boton
     * Detecta cual boton fue presionado con e.getSource()
     * y llama al metodo correspondiente
     *
     * ES LLAMADO POR: btnIngresar y btnSalir
     *                 (ambos tienen addActionListener(this))
     */
    public void actionPerformed(ActionEvent e) {

        // si se presiono el boton INGRESAR
        if (e.getSource() == btnIngresar) {
            actionPerformedBtnIngresar(e); // llama al metodo de ingresar
        }

        // si se presiono el boton SALIR
        if (e.getSource() == btnSalir) {
            actionPerformedBtnSalir(e); // llama al metodo de salir
        }
    }

    /*
     * METODO actionPerformedBtnSalir (VOID)
     * Cierra completamente el programa
     * System.exit(0) termina todos los procesos de Java
     *
     * ES LLAMADO POR: actionPerformed cuando detecta btnSalir
     * PARAMETRO: e = evento que genero la accion
     */
    protected void actionPerformedBtnSalir(ActionEvent e) {
        System.exit(0); // cierra todo el programa completamente
    }

    /*
     * METODO actionPerformedBtnIngresar (VOID)
     * Abre la ventana de Login para que el usuario
     * ingrese su usuario y contraseña
     * Luego cierra esta ventana de bienvenida
     *
     * ES LLAMADO POR: actionPerformed cuando detecta btnIngresar
     * PARAMETRO: e = evento que genero la accion
     */
    protected void actionPerformedBtnIngresar(ActionEvent e) {

        // crea y muestra la ventana de Login
        Ven_Login vp = new Ven_Login();
        vp.setVisible(true);

        // cierra esta ventana de bienvenida
        // Ven_IngresarUsuario.this hace referencia a esta misma ventana
        Ven_IngresarUsuario.this.dispose();
    }
}