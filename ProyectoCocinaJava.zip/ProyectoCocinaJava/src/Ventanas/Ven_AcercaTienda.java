package Ventanas;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.Color;

/*
 * VENTANA ACERCA DE TIENDA
 * Muestra informacion del programa:
 *   - Nombre del programa
 *   - Autores
 *   - Boton Cerrar
 */
public class Ven_AcercaTienda extends JFrame implements ActionListener {

    private static final long serialVersionUID = 1L;

    private JPanel contentPane;
    private JPanel panelInfo;
    private JButton btnCerrar;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Ven_AcercaTienda frame = new Ven_AcercaTienda();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /*
     * CONSTRUCTOR
     * Crea la ventana y llama a crearContenido()
     */
    public Ven_AcercaTienda() {
        setTitle("Acerca de Tienda");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 420, 380);
        setLocationRelativeTo(null);
        setResizable(false);

        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        contentPane.setLayout(null);
        setContentPane(contentPane);

        // panel interior con borde
        panelInfo = new JPanel();
        panelInfo.setLayout(null);
        panelInfo.setBorder(new LineBorder(Color.GRAY, 1));
        panelInfo.setBounds(10, 10, 385, 330);
        contentPane.add(panelInfo);

        crearContenido();
    }

    /*
     * METODO crearContenido (VOID)
     * Agrega todos los labels y el boton al panel
     *
     * ES LLAMADO POR: constructor
     */
    public void crearContenido() {

        // -- titulo principal --
        JLabel lblTitulo = new JLabel("TIENDA N°1");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 28));
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitulo.setBounds(0, 20, 385, 40);
        panelInfo.add(lblTitulo);

        // -- linea separadora --
        JSeparator separador = new JSeparator();
        separador.setBounds(20, 75, 345, 2);
        panelInfo.add(separador);

        // -- titulo autores --
        JLabel lblAutores = new JLabel("Autores");
        lblAutores.setFont(new Font("Arial", Font.PLAIN, 14));
        lblAutores.setHorizontalAlignment(SwingConstants.CENTER);
        lblAutores.setBounds(0, 90, 385, 25);
        panelInfo.add(lblAutores);

        // -- autor 1 --
        JLabel lblAutor1 = new JLabel("Erik Saldarriaga Cerquin");
        lblAutor1.setFont(new Font("Arial", Font.PLAIN, 13));
        lblAutor1.setHorizontalAlignment(SwingConstants.CENTER);
        lblAutor1.setBounds(0, 140, 385, 20);
        panelInfo.add(lblAutor1);

        // -- autor 2 --
        JLabel lblAutor2 = new JLabel("Angel Adrian Lujan Flores");
        lblAutor2.setFont(new Font("Arial", Font.PLAIN, 13));
        lblAutor2.setHorizontalAlignment(SwingConstants.CENTER);
        lblAutor2.setBounds(0, 175, 385, 20);
        panelInfo.add(lblAutor2);

        // -- boton Cerrar --
        btnCerrar = new JButton("Cerrar");
        btnCerrar.setBounds(143, 275, 100, 25);
        btnCerrar.addActionListener(this);
        panelInfo.add(btnCerrar);
    }

    /*
     * METODO actionPerformed (VOID)
     * Detecta que boton fue presionado
     *
     * ES LLAMADO POR: btnCerrar
     */
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnCerrar) {
            accionCerrar();
        }
    }

    /*
     * METODO accionCerrar (VOID)
     * Cierra solo esta ventana
     *
     * ES LLAMADO POR: actionPerformed
     */
    public void accionCerrar() {
        dispose();
    }
}