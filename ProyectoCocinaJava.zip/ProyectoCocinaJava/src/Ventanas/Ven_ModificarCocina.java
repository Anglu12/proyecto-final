package Ventanas;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

/*
 * VENTANA MODIFICAR COCINA
 * Esta ventana permite seleccionar una cocina del combo
 * y modificar sus datos (precio, ancho, alto, fondo)
 * Luego se pueden guardar los cambios con el boton Guardar
 */
public class Ven_ModificarCocina extends JFrame implements ActionListener {

    private static final long serialVersionUID = 1L;

    // ---- COMPONENTES DE LA VENTANA ---- // 
    private JPanel contentPane;
    private JTextField TxtPrecio;   
    private JTextField TxtAncho;    
    private JTextField TxtAlto;     
    private JTextField TxtFondo;    
    private JComboBox<String> cboModeloCocina; // lista desplegable de modelos // 
    private JButton btnCerrar;      // boton para cerrar la ventana //
    private JButton btnGuardar;     // boton para guardar los cambios //
    private boolean cargando = false; // controla si se estan cargando datos
    
    // ---- VARIABLES AUXILIARES ----
    // guardan temporalmente los valores que el usuario escribe
    private int modeloSeleccionado; // numero del modelo elegido (0,1,2,3,4)
    private double precio;          // precio que escribe el usuario
    private double ancho;           // ancho que escribe el usuario
    private double alto;            // alto que escribe el usuario
    private double fondo;           // fondo que escribe el usuario

    /*
     * METODO MAIN
     * Este es el punto de inicio del programa
     * Solo se usa cuando ejecutamos esta ventana directamente
     * para probarla sin pasar por el menu principal
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    // crea y muestra la ventana
                    Ven_ModificarCocina frame = new Ven_ModificarCocina();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    
    // * CONSTRUCTOR - Ven_ModificarCocina() //
     // Se ejecuta automaticamente cuando hacemos:
     // Ven_ModificarCocina vm = new Ven_ModificarCocina(); //
     
    public Ven_ModificarCocina() {
        setTitle("Modificar Cocina");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 450, 300);
        setLocationRelativeTo(null); // centra la ventana en la pantalla
        setResizable(false);         // no permite cambiar el tamanio

        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setLayout(null);
        setContentPane(contentPane);

        // -- etiqueta y combo de modelo --//
        JLabel lblModelo = new JLabel("Modelo:");
        lblModelo.setBounds(57, 46, 76, 12);
        contentPane.add(lblModelo);

        // se agregan los modelos uno por uno al combo
        cboModeloCocina = new JComboBox<String>();
        cboModeloCocina.addItem("Cocina Indurama Quarzo"); // indice 0
        cboModeloCocina.addItem("Cocina Mabe EM6010");     // indice 1
        cboModeloCocina.addItem("Cocina Coldex CG560");    // indice 2
        cboModeloCocina.addItem("Cocina Surge Premium");   // indice 3
        cboModeloCocina.addItem("Cocina Miray CG560G");    // indice 4
        cboModeloCocina.setBounds(143, 42, 165, 20);
        cboModeloCocina.addActionListener(this); // llama a actionPerformed cuando cambia
        contentPane.add(cboModeloCocina);

        // -- etiqueta y campo de precio --//
        JLabel lblPrecio = new JLabel("Precio (S/):");
        lblPrecio.setBounds(57, 87, 80, 12);
        contentPane.add(lblPrecio);

        TxtPrecio = new JTextField(); // campo editable para escribir precio
        TxtPrecio.setBounds(143, 84, 165, 18);
        contentPane.add(TxtPrecio);

        // -- etiqueta y campo de ancho --
        JLabel lblAncho = new JLabel("Ancho (cm):");
        lblAncho.setBounds(57, 116, 80, 12);
        contentPane.add(lblAncho);

        TxtAncho = new JTextField(); // campo editable para escribir ancho
        TxtAncho.setBounds(143, 113, 165, 18);
        contentPane.add(TxtAncho);

        // -- etiqueta y campo de alto --
        JLabel lblAlto = new JLabel("Alto (cm):");
        lblAlto.setBounds(57, 146, 80, 12);
        contentPane.add(lblAlto);

        TxtAlto = new JTextField(); // campo editable para escribir alto
        TxtAlto.setBounds(143, 143, 165, 18);
        contentPane.add(TxtAlto);

        // -- etiqueta y campo de fondo --
        JLabel lblFondo = new JLabel("Fondo (cm):");
        lblFondo.setBounds(57, 176, 80, 12);
        contentPane.add(lblFondo);

        TxtFondo = new JTextField(); // campo editable para escribir fondo
        TxtFondo.setBounds(143, 173, 165, 18);
        contentPane.add(TxtFondo);

        // -- boton cerrar --
        btnCerrar = new JButton("Cerrar");
        btnCerrar.setBounds(342, 42, 84, 20);
        btnCerrar.addActionListener(this); // llama a actionPerformed cuando se presiona
        contentPane.add(btnCerrar);

        // -- boton guardar --
        btnGuardar = new JButton("Guardar");
        btnGuardar.setBounds(342, 72, 84, 20);
        btnGuardar.addActionListener(this); // llama a actionPerformed cuando se presiona
        contentPane.add(btnGuardar);

        // al abrir la ventana muestra automaticamente la primera cocina
        // llama al metodo mostrarDatos con indice 0
        mostrarDatos(0);
    }

    /*
     * METODO actionPerformed (VOID)
     * Este metodo se ejecuta automaticamente cada vez que
     * el usuario presiona un boton o cambia el combo
     * Detecta cual componente fue activado con e.getSource()
     * y llama al metodo correspondiente
     *
     * ES LLAMADO POR: btnCerrar, btnGuardar, cboModeloCocina
     *                 (todos tienen addActionListener(this))
     */
    public void actionPerformed(ActionEvent e) {

        // si se presiono el boton Cerrar
        if (e.getSource() == btnCerrar) {
            accionCerrar(); // llama al metodo accionCerrar
        }

        // si se cambio la seleccion del combo
        if (e.getSource() == cboModeloCocina) {
            accionCombo(); // llama al metodo accionCombo
        }

        // si se presiono el boton Guardar
        if (e.getSource() == btnGuardar) {
            accionGuardar(); // llama al metodo accionGuardar
        }
    }

    /*
     * METODO accionCerrar (VOID)
     * Cierra solo esta ventana sin cerrar el programa
     * dispose() libera los recursos de la ventana
     *
     * ES LLAMADO POR: actionPerformed cuando detecta btnCerrar
     */
    public void accionCerrar() {
        dispose(); // cierra solo esta ventana
    }

    /*
     * METODO accionCombo (VOID)
     * Se ejecuta cuando el usuario cambia de cocina en el combo
     * Obtiene el numero del modelo seleccionado (0,1,2,3,4)
     * y llama a mostrarDatos para actualizar los campos
     *
     * ES LLAMADO POR: actionPerformed cuando detecta cboModeloCocina
     */
    public void accionCombo() {
    	if (!cargando) { //  solo actua si NO estamos cargando // 
        modeloSeleccionado = cboModeloCocina.getSelectedIndex();
        mostrarDatos(modeloSeleccionado); // llama a mostrarDatos con el indice elegido
    }
    }

    /*
     * METODO mostrarDatos (VOID)
     * Recibe el numero del modelo (0,1,2,3,4)
     * y muestra sus datos en los campos de texto
     * Los datos vienen de las variables globales de Ven_Principal
     *
     * ES LLAMADO POR: constructor (al abrir) y accionCombo (al cambiar combo)
     * PARAMETRO: modelo = numero de la cocina a mostrar
     */
    public void mostrarDatos(int modelo) {
    	cargando = true; //  indica que estamos cargando, no escribiendo //
        if (modelo == 0) {
            TxtPrecio.setText(String.valueOf(Ven_Principal.precio0));
            TxtAncho.setText(String.valueOf(Ven_Principal.ancho0));
            TxtAlto.setText(String.valueOf(Ven_Principal.alto0));
            TxtFondo.setText(String.valueOf(Ven_Principal.fondo0));
        }
        if (modelo == 1) {
            TxtPrecio.setText(String.valueOf(Ven_Principal.precio1));
            TxtAncho.setText(String.valueOf(Ven_Principal.ancho1));
            TxtAlto.setText(String.valueOf(Ven_Principal.alto1));
            TxtFondo.setText(String.valueOf(Ven_Principal.fondo1));
        }
        if (modelo == 2) {
            TxtPrecio.setText(String.valueOf(Ven_Principal.precio2));
            TxtAncho.setText(String.valueOf(Ven_Principal.ancho2));
            TxtAlto.setText(String.valueOf(Ven_Principal.alto2));
            TxtFondo.setText(String.valueOf(Ven_Principal.fondo2));
        }
        if (modelo == 3) {
            TxtPrecio.setText(String.valueOf(Ven_Principal.precio3));
            TxtAncho.setText(String.valueOf(Ven_Principal.ancho3));
            TxtAlto.setText(String.valueOf(Ven_Principal.alto3));
            TxtFondo.setText(String.valueOf(Ven_Principal.fondo3));
        }
        if (modelo == 4) {
            TxtPrecio.setText(String.valueOf(Ven_Principal.precio4));
            TxtAncho.setText(String.valueOf(Ven_Principal.ancho4));
            TxtAlto.setText(String.valueOf(Ven_Principal.alto4));
            TxtFondo.setText(String.valueOf(Ven_Principal.fondo4));
        }
        cargando = false; //  termina la carga, ya puede escribir // 
    }

    /*
     * METODO obtenerPrecio (RETORNA double)
     * Lee el texto del campo TxtPrecio
     * y lo convierte a numero decimal (double)
     *
     * ES LLAMADO POR: accionGuardar
     * RETORNA: el precio escrito como numero double
     */
    public double obtenerPrecio() {
        double valor = Double.parseDouble(TxtPrecio.getText());
        return valor;
    }

    /*
     * METODO obtenerAncho (RETORNA double)
     * Lee el texto del campo TxtAncho
     * y lo convierte a numero decimal (double)
     *
     * ES LLAMADO POR: accionGuardar
     * RETORNA: el ancho escrito como numero double
     */
    public double obtenerAncho() {
        double valor = Double.parseDouble(TxtAncho.getText());
        return valor;
    }

    /*
     * METODO obtenerAlto (RETORNA double)
     * Lee el texto del campo TxtAlto
     * y lo convierte a numero decimal (double)
     *
     * ES LLAMADO POR: accionGuardar
     * RETORNA: el alto escrito como numero double
     */
    public double obtenerAlto() {
        double valor = Double.parseDouble(TxtAlto.getText());
        return valor;
    }

    /*
     * METODO obtenerFondo (RETORNA double)
     * Lee el texto del campo TxtFondo
     * y lo convierte a numero decimal (double)
     *
     * ES LLAMADO POR: accionGuardar
     * RETORNA: el fondo escrito como numero double
     */
    public double obtenerFondo() {
        double valor = Double.parseDouble(TxtFondo.getText());
        return valor;
    }

    /*
     * METODO accionGuardar (VOID)
     * Se ejecuta cuando el usuario presiona el boton Guardar
     * Llama a los metodos obtener para leer cada campo
     * Guarda los nuevos valores en las variables de Ven_Principal
     * Si el usuario escribio letras en vez de numeros muestra un error
     *
     * ES LLAMADO POR: actionPerformed cuando detecta btnGuardar
     */
    public void accionGuardar() {
        try { // “Ejecuta este bloque… pero si ocurre un error, no detengas el programa, mejor contrólalo.” //
            // llama a los metodos de retorno para obtener cada valor
            precio = obtenerPrecio();
            ancho  = obtenerAncho();
            alto   = obtenerAlto();
            fondo  = obtenerFondo();

            // obtiene cual cocina esta seleccionada en el combo
            modeloSeleccionado = cboModeloCocina.getSelectedIndex();

            // guarda los nuevos valores en las variables globales de Ven_Principal
            if (modeloSeleccionado == 0) {
                Ven_Principal.precio0 = precio;
                Ven_Principal.ancho0  = ancho;
                Ven_Principal.alto0   = alto;
                Ven_Principal.fondo0  = fondo;
            }
            if (modeloSeleccionado == 1) {
                Ven_Principal.precio1 = precio;
                Ven_Principal.ancho1  = ancho;
                Ven_Principal.alto1   = alto;
                Ven_Principal.fondo1  = fondo;
            }
            if (modeloSeleccionado == 2) {
                Ven_Principal.precio2 = precio;
                Ven_Principal.ancho2  = ancho;
                Ven_Principal.alto2   = alto;
                Ven_Principal.fondo2  = fondo;
            }
            if (modeloSeleccionado == 3) {
                Ven_Principal.precio3 = precio;
                Ven_Principal.ancho3  = ancho;
                Ven_Principal.alto3   = alto;
                Ven_Principal.fondo3  = fondo;
            }
            if (modeloSeleccionado == 4) {
                Ven_Principal.precio4 = precio;
                Ven_Principal.ancho4  = ancho;
                Ven_Principal.alto4   = alto;
                Ven_Principal.fondo4  = fondo;
            }

            // muestra mensaje de exito y cierra la ventana
            JOptionPane.showMessageDialog(null,
                "Datos guardados correctamente",
                "Guardar",
                JOptionPane.INFORMATION_MESSAGE);

            dispose(); // cierra la ventana despues de guardar

        } catch (NumberFormatException ex) { // En vez de que el programa se cierre,  Hace esto 	// 
            // si el usuario escribio letras muestra este error
            JOptionPane.showMessageDialog(null,
                "Por favor ingrese solo numeros en los campos",
                "Error de datos",
                JOptionPane.ERROR_MESSAGE);
        }
    }
}