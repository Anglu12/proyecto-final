package Ventanas;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

/*
 * VENTANA CONFIGURAR OBSEQUIOS
 * Esta ventana permite modificar los obsequios
 * segun la cantidad de unidades compradas
 * Tiene 3 rangos:
 *   - 1 unidad
 *   - 2 a 5 unidades
 *   - 6 a mas unidades
 */
public class Ven_ConfigurarObsequios extends JFrame implements ActionListener {

    private static final long serialVersionUID = 1L;

    // ---- COMPONENTES DE LA VENTANA ----
    private JPanel contentPane;
    private JTextField TxtObsequio1; // campo para 1 unidad
    private JTextField TxtObsequio2; // campo para 2 a 5 unidades
    private JTextField TxtObsequio3; // campo para 6 a mas unidades
    private JButton btnAceptar;      // boton para guardar los obsequios
    private JButton btnCancelar;     // boton para cerrar sin guardar

    // ---- VARIABLES GLOBALES DE OBSEQUIOS ----
    // estas variables guardan los obsequios actuales
    // son publicas y estaticas para que otras ventanas puedan usarlas
    public static String obsequio1 = "Cafetera";   // obsequio para 1 unidad
    public static String obsequio2 = "Licuadora";  // obsequio para 2 a 5 unidades
    public static String obsequio3 = "Extractor";  // obsequio para 6 a mas unidades

    /*
     * METODO MAIN
     * Solo se usa para probar esta ventana directamente
     * sin pasar por el menu principal
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Ven_ConfigurarObsequios frame = new Ven_ConfigurarObsequios();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /*
     * CONSTRUCTOR - Ven_ConfigurarObsequios()
     * Se ejecuta cuando hacemos:
     *    Ven_ConfigurarObsequios vo = new Ven_ConfigurarObsequios();
     * Crea todos los componentes de la ventana
     * Al final llama a mostrarObsequios() para mostrar los valores actuales
     */
    public Ven_ConfigurarObsequios() {
        setTitle("Configurar obsequios");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 480, 200);
        setLocationRelativeTo(null); // centra la ventana
        setResizable(false);

        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setLayout(null);
        setContentPane(contentPane);

        // -- fila 1: 1 unidad --
        JLabel lbl1 = new JLabel("1 unidad:");
        lbl1.setBounds(20, 30, 130, 20);
        contentPane.add(lbl1);

        TxtObsequio1 = new JTextField();
        TxtObsequio1.setBounds(160, 28, 150, 22);
        contentPane.add(TxtObsequio1);

        // -- fila 2: 2 a 5 unidades --
        JLabel lbl2 = new JLabel("2 a 5 unidades:");
        lbl2.setBounds(20, 65, 130, 20);
        contentPane.add(lbl2);

        TxtObsequio2 = new JTextField();
        TxtObsequio2.setBounds(160, 63, 150, 22);
        contentPane.add(TxtObsequio2);

        // -- fila 3: 6 a mas unidades --
        JLabel lbl3 = new JLabel("6 a más unidades:");
        lbl3.setBounds(20, 100, 130, 20);
        contentPane.add(lbl3);

        TxtObsequio3 = new JTextField();
        TxtObsequio3.setBounds(160, 98, 150, 22);
        contentPane.add(TxtObsequio3);

        // -- boton Aceptar --
        btnAceptar = new JButton("Aceptar");
        btnAceptar.setBounds(360, 28, 90, 25);
        btnAceptar.addActionListener(this); // llama a actionPerformed
        contentPane.add(btnAceptar);

        // -- boton Cancelar --
        btnCancelar = new JButton("Cancelar");
        btnCancelar.setBounds(360, 63, 90, 25);
        btnCancelar.addActionListener(this); // llama a actionPerformed
        contentPane.add(btnCancelar);

        // al abrir muestra los obsequios actuales
        mostrarObsequios();
    }

    /*
     * METODO actionPerformed (VOID)
     * Se ejecuta cuando el usuario presiona un boton
     * Detecta cual boton fue presionado y llama al metodo correcto
     *
     * ES LLAMADO POR: btnAceptar y btnCancelar // 
     * public void modificado de acceso
     * Significa que el método se puede usar desde cualquier otra clase
     */ 
    public void actionPerformed(ActionEvent e) {

        // si presiono Aceptar
        if (e.getSource() == btnAceptar) {
            accionAceptar(); // llama al metodo accionAceptar
        }

        // si presiono Cancelar
        if (e.getSource() == btnCancelar) {
            accionCancelar(); // llama al metodo accionCancelar
        }
    }

    /*
     * METODO mostrarObsequios (VOID)
     * Muestra los obsequios actuales en los campos de texto
     * Los valores vienen de las variables globales obsequio1, obsequio2, obsequio3
     *
     * ES LLAMADO POR: constructor (al abrir la ventana)
     */
    public void mostrarObsequios() {
        TxtObsequio1.setText(obsequio1);
        TxtObsequio2.setText(obsequio2);
        TxtObsequio3.setText(obsequio3);
    }

    /*
     * METODO obtenerObsequio1 (RETORNA String)
     * Lee el texto del campo TxtObsequio1
     *
     * ES LLAMADO POR: accionAceptar
     * RETORNA: el texto escrito en el campo como String
     */
    public String obtenerObsequio1() {
        String valor = TxtObsequio1.getText();
        return valor;
    }

    /*
     * METODO obtenerObsequio2 (RETORNA String)
     * Lee el texto del campo TxtObsequio2
     *
     * ES LLAMADO POR: accionAceptar
     * RETORNA: el texto escrito en el campo como String
     */
    public String obtenerObsequio2() {
        String valor = TxtObsequio2.getText();
        return valor;
    }

    /*
     * METODO obtenerObsequio3 (RETORNA String)
     * Lee el texto del campo TxtObsequio3
     *
     * ES LLAMADO POR: accionAceptar
     * RETORNA: el texto escrito en el campo como String
     */
    public String obtenerObsequio3() {
        String valor = TxtObsequio3.getText();
        return valor;
    }

    /*
     * METODO accionAceptar (VOID)
     * Lee los valores escritos usando los metodos obtener
     * Verifica que los campos no esten vacios
     * Guarda los nuevos obsequios en las variables globales
     * Muestra mensaje de confirmacion y cierra la ventana
     *
     * ES LLAMADO POR: actionPerformed cuando detecta btnAceptar
     */
    public void accionAceptar() {

        // llama a los metodos de retorno para leer cada campo
        String nuevoObsequio1 = obtenerObsequio1();
        String nuevoObsequio2 = obtenerObsequio2();
        String nuevoObsequio3 = obtenerObsequio3();

        // verifica que ningun campo este vacio
        if (nuevoObsequio1.isEmpty() || nuevoObsequio2.isEmpty() || nuevoObsequio3.isEmpty()) {
            JOptionPane.showMessageDialog(null,
                "Por favor complete todos los campos",
                "Error",
                JOptionPane.ERROR_MESSAGE);
            return; // sale del metodo sin guardar
        }

        // guarda los nuevos obsequios en las variables globales
        obsequio1 = nuevoObsequio1;
        obsequio2 = nuevoObsequio2;
        obsequio3 = nuevoObsequio3;

        // muestra mensaje de exito
        JOptionPane.showMessageDialog(null,
            "Obsequios guardados correctamente",
            "Aceptar",
            JOptionPane.INFORMATION_MESSAGE);

        dispose(); // cierra la ventana
    }

    /*
     * METODO accionCancelar (VOID)
     * Cierra la ventana sin guardar ningun cambio
     *
     * ES LLAMADO POR: actionPerformed cuando detecta btnCancelar
     */
    public void accionCancelar() {
        dispose(); // cierra solo esta ventana sin guardar
    }
}